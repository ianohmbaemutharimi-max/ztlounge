/**
 * ============================================================
 * ZT Lounge Meru - Booking JavaScript
 * Enterprise Booking Engine for all booking forms
 * 
 * Architecture: Configuration → DOM Cache → Validation → UI → Form Handler → Engine
 * ============================================================
 */

(function() {
    'use strict';

    // ============================================================
    // 1. CONFIGURATION
    // ============================================================
    const BOOKING_CONFIG = {
        // Selectors
        bookingFormSelector: '.booking-form',
        formSelector: 'form',
        formContainerSelector: '.form-container',

        // CSS Classes
        errorClass: 'error',
        errorVisibleClass: 'visible',
        fieldErrorClass: 'field-error',
        bookingSuccessClass: 'booking-success',
        bookingErrorClass: 'booking-error',

        // Validation
        minPhoneLength: 8,
        minGuestCount: 1,
        defaultDateOffset: 1,

        // Regex Patterns
        emailPattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        phonePattern: /^[\+\d\s\-()]{8,20}$/,

        // Timing
        successScrollDelay: 600,
        successFadeDuration: 600,

        // URL Parameters
        urlParamService: 'service',
        urlParamDate: 'date',
        urlParamGuests: 'guests',

        // Session Storage
        sessionKey: 'zt_booking_intent',

        // Scroll
        scrollOffset: 80
    };

    // ============================================================
    // 2. DOM CACHE
    // ============================================================
    const DOM = {
        /**
         * Get all booking forms
         */
        getForms: function() {
            return document.querySelectorAll(
                BOOKING_CONFIG.bookingFormSelector + ' ' + BOOKING_CONFIG.formSelector
            );
        },

        /**
         * Get form elements with caching
         */
        getFormElements: function(form) {
            // Cache elements on the form instance
            if (!form._cachedElements) {
                form._cachedElements = {
                    inputs: form.querySelectorAll('input, select, textarea'),
                    requiredInputs: form.querySelectorAll(
                        'input[required], select[required], textarea[required]'
                    ),
                    submitButton: form.querySelector('button[type="submit"]'),
                    container: form.closest(BOOKING_CONFIG.formContainerSelector) || form.parentElement
                };
            }
            return form._cachedElements;
        },

        /**
         * Get field error element by input ID
         */
        getFieldError: function(input) {
            const errorMap = {
                'fullName': 'fullNameError',
                'email': 'emailError',
                'phone': 'phoneError',
                'phoneNumber': 'phoneError',
                'service': 'serviceError',
                'eventType': 'eventTypeError',
                'guestCount': 'guestError',
                'guests': 'guestError',
                'attendees': 'attendeesError',
                'bookingDate': 'dateError',
                'eventDate': 'dateError',
                'bookingTime': 'timeError',
                'eventTime': 'timeError',
                'duration': 'durationError'
            };
            const errorId = errorMap[input.id];
            return errorId ? document.getElementById(errorId) : null;
        },

        /**
         * Check if current page is contact page
         */
        isContactPage: function() {
            return window.location.pathname.includes('contact.html');
        },

        /**
         * Get URL parameters
         */
        getUrlParams: function() {
            return new URLSearchParams(window.location.search);
        },

        /**
         * Find booking section for scrolling
         */
        getBookingSection: function() {
            return document.querySelector('.booking-section') || 
                   document.querySelector('#booking') ||
                   document.querySelector('#booking-form');
        },

        /**
         * Get quick booking buttons
         */
        getQuickBookingButtons: function() {
            return document.querySelectorAll('.quick-book, .cta-buttons .btn-primary');
        }
    };

    // ============================================================
    // 3. VALIDATION ENGINE
    // ============================================================
    const Validator = {
        /**
         * Validation rule definitions
         */
        rules: {
            required: {
                validate: function(value) {
                    return value && value.trim().length > 0;
                },
                message: 'This field is required'
            },
            email: {
                validate: function(value) {
                    if (!value || !value.trim()) return true;
                    return BOOKING_CONFIG.emailPattern.test(value.trim());
                },
                message: 'Please enter a valid email address'
            },
            phone: {
                validate: function(value) {
                    if (!value || !value.trim()) return true;
                    return BOOKING_CONFIG.phonePattern.test(value.trim());
                },
                message: 'Please enter a valid phone number'
            },
            date: {
                validate: function(value) {
                    if (!value) return false;
                    const selectedDate = new Date(value);
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    return selectedDate >= today;
                },
                message: 'Please select a future date'
            },
            guests: {
                validate: function(value) {
                    if (!value) return false;
                    const guests = parseInt(value);
                    return !isNaN(guests) && guests >= BOOKING_CONFIG.minGuestCount;
                },
                message: 'Please enter at least 1 guest'
            }
        },

        /**
         * Get validation rules for a field
         */
        getRulesForField: function(input) {
            const rules = [];

            if (input.hasAttribute('required')) {
                rules.push('required');
            }

            switch (input.type) {
                case 'email':
                    rules.push('email');
                    break;
                case 'tel':
                    rules.push('phone');
                    break;
                case 'date':
                    rules.push('date');
                    break;
            }

            if (input.id === 'guests' || input.id === 'guestCount' || input.id === 'attendees') {
                rules.push('guests');
            }

            return rules;
        },

        /**
         * Validate a single field
         */
        validateField: function(input) {
            const value = input.value;
            const rules = this.getRulesForField(input);
            let isValid = true;
            let errorMessage = '';

            for (const ruleName of rules) {
                const rule = this.rules[ruleName];
                if (rule && !rule.validate(value)) {
                    isValid = false;
                    errorMessage = rule.message;
                    break;
                }
            }

            return { isValid, errorMessage };
        },

        /**
         * Validate all required fields in a form
         */
        validateForm: function(form) {
            const elements = DOM.getFormElements(form);
            let isValid = true;

            elements.requiredInputs.forEach(function(input) {
                const result = Validator.validateField(input);
                if (!result.isValid) {
                    isValid = false;
                }
            });

            return isValid;
        }
    };

    // ============================================================
    // 4. UI CONTROLLER
    // ============================================================
    const UIController = {
        /**
         * Show field error
         */
        showFieldError: function(input, message) {
            input.classList.add(BOOKING_CONFIG.errorClass);
            input.setAttribute('aria-invalid', 'true');

            const errorEl = DOM.getFieldError(input);
            if (errorEl) {
                errorEl.textContent = message;
                errorEl.classList.add(BOOKING_CONFIG.errorVisibleClass);
                input.setAttribute('aria-describedby', errorEl.id);
            }
        },

        /**
         * Clear field error
         */
        clearFieldError: function(input) {
            input.classList.remove(BOOKING_CONFIG.errorClass);
            input.removeAttribute('aria-invalid');
            input.removeAttribute('aria-describedby');

            const errorEl = DOM.getFieldError(input);
            if (errorEl) {
                errorEl.classList.remove(BOOKING_CONFIG.errorVisibleClass);
            }
        },

        /**
         * Clear all errors in a form
         */
        clearAllErrors: function(form) {
            const elements = DOM.getFormElements(form);
            elements.inputs.forEach(function(input) {
                UIController.clearFieldError(input);
            });

            // Remove any booking error messages
            const bookingError = form.querySelector('.' + BOOKING_CONFIG.bookingErrorClass);
            if (bookingError) {
                bookingError.remove();
            }
        },

        /**
         * Disable form inputs
         */
        disableForm: function(form) {
            const elements = DOM.getFormElements(form);
            elements.inputs.forEach(function(input) {
                input.disabled = true;
            });
            if (elements.submitButton) {
                elements.submitButton.disabled = true;
            }
        },

        /**
         * Enable form inputs
         */
        enableForm: function(form) {
            const elements = DOM.getFormElements(form);
            elements.inputs.forEach(function(input) {
                input.disabled = false;
            });
            if (elements.submitButton) {
                elements.submitButton.disabled = false;
            }
        },

        /**
         * Show booking success state
         */
        showSuccess: function(form) {
            // Disable form
            this.disableForm(form);

            // Store original content
            const originalContent = form.innerHTML;

            // Create success message
            const successDiv = document.createElement('div');
            successDiv.className = BOOKING_CONFIG.bookingSuccessClass;
            successDiv.setAttribute('role', 'status');
            successDiv.setAttribute('aria-live', 'polite');
            successDiv.innerHTML = this.buildSuccessHTML();

            // Replace content
            form.innerHTML = '';
            form.appendChild(successDiv);
            form.classList.add('booking-success-state');

            // Store original content for reset
            form._originalContent = originalContent;

            // Scroll to success
            setTimeout(function() {
                successDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 100);

            // Log success
            console.log('✅ Booking confirmed successfully');
        },

        /**
         * Build success HTML (presentation-free, uses theme classes)
         */
        buildSuccessHTML: function() {
            return `
                <div class="booking-success-content">
                    <div class="success-icon">
                        <i class="fas fa-check-circle" aria-hidden="true"></i>
                    </div>
                    <h3 class="success-title">Booking Confirmed!</h3>
                    <p class="success-message">Thank you for booking with ZT Lounge Meru.</p>
                    <p class="success-message-sub">We will contact you shortly to confirm your reservation.</p>
                    <button type="button" class="btn btn-primary success-reload-btn" data-reload>
                        <i class="fas fa-plus" aria-hidden="true"></i> Make Another Booking
                    </button>
                </div>
            `;
        },

        /**
         * Show booking error state
         */
        showError: function(form, message) {
            // Remove existing error
            const existingError = form.querySelector('.' + BOOKING_CONFIG.bookingErrorClass);
            if (existingError) {
                existingError.remove();
            }

            // Create error message
            const errorDiv = document.createElement('div');
            errorDiv.className = BOOKING_CONFIG.bookingErrorClass;
            errorDiv.setAttribute('role', 'alert');
            errorDiv.innerHTML = this.buildErrorHTML(message || 'Something went wrong. Please try again.');

            // Insert at top of form
            form.prepend(errorDiv);

            // Re-enable form
            this.enableForm(form);

            // Scroll to error
            errorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
        },

        /**
         * Build error HTML (presentation-free, uses theme classes)
         */
        buildErrorHTML: function(message) {
            return `
                <div class="booking-error-content">
                    <i class="fas fa-exclamation-circle error-icon" aria-hidden="true"></i>
                    <span class="error-message">${message}</span>
                </div>
            `;
        },

        /**
         * Reset form to original state
         */
        resetForm: function(form) {
            const originalContent = form._originalContent;
            if (originalContent) {
                form.innerHTML = originalContent;
                form.classList.remove('booking-success-state');
                this.enableForm(form);
                delete form._originalContent;
            }
        }
    };

    // ============================================================
    // 5. BOOKING FORM HANDLER
    // ============================================================
    class BookingFormHandler {
        /**
         * Create a booking form handler
         */
        constructor(form) {
            this.form = form;
            this.elements = DOM.getFormElements(form);
            this.isSubmitting = false;

            this.bindEvents();
            this.applyUrlParams();
            this.handleBookingIntent();
        }

        /**
         * Bind form events
         */
        bindEvents() {
            // Submit handler
            this.form.addEventListener('submit', function(e) {
                e.preventDefault();
                this.handleSubmit();
            }.bind(this));

            // Real-time validation on blur
            this.elements.inputs.forEach(function(input) {
                input.addEventListener('blur', function() {
                    this.validateInput(input);
                }.bind(this));

                input.addEventListener('input', function() {
                    if (input.classList.contains(BOOKING_CONFIG.errorClass)) {
                        this.validateInput(input);
                    }
                }.bind(this));
            }.bind(this));

            // Reload button handler (event delegation)
            this.form.addEventListener('click', function(e) {
                const target = e.target.closest('[data-reload]');
                if (target) {
                    window.location.reload();
                }
            });
        }

        /**
         * Validate a single input with accessibility
         */
        validateInput: function(input) {
            const result = Validator.validateField(input);

            if (!result.isValid) {
                UIController.showFieldError(input, result.errorMessage);
            } else {
                UIController.clearFieldError(input);
            }

            return result.isValid;
        }

        /**
         * Validate entire form
         */
        validateForm: function() {
            let isValid = true;
            const requiredInputs = this.elements.requiredInputs;

            requiredInputs.forEach(function(input) {
                if (!this.validateInput(input)) {
                    isValid = false;
                }
            }.bind(this));

            return isValid;
        }

        /**
         * Handle form submission
         */
        handleSubmit: function() {
            if (this.isSubmitting) return;

            UIController.clearAllErrors(this.form);

            if (!this.validateForm()) {
                // Scroll to first error
                const firstError = this.form.querySelector('.' + BOOKING_CONFIG.errorClass);
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                return;
            }

            this.isSubmitting = true;
            this.submitToServer();
        }

        /**
         * Submit to server (production ready)
         */
        submitToServer: function() {
            const formData = new FormData(this.form);
            const data = this.collectFormData(formData);

            // Log booking for demo
            this.logBooking(data);

            // Demo: Show success immediately
            // In production, use fetch pattern below
            UIController.showSuccess(this.form);
            this.isSubmitting = false;

            // ===== PRODUCTION FETCH PATTERN =====
            /*
            fetch('/api/booking', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    UIController.showSuccess(this.form);
                } else {
                    UIController.showError(this.form, result.message);
                }
                this.isSubmitting = false;
            })
            .catch(error => {
                UIController.showError(this.form, 'Network error. Please try again.');
                this.isSubmitting = false;
            });
            */
        }

        /**
         * Collect form data with metadata
         */
        collectFormData: function(formData) {
            const data = Object.fromEntries(formData.entries());
            data.timestamp = new Date().toISOString();
            data.source = window.location.pathname;
            data.referrer = document.referrer || 'direct';
            return data;
        }

        /**
         * Log booking (development only)
         */
        logBooking: function(data) {
            console.log('📅 Booking submitted:', data);
        }

        /**
         * Apply URL parameters to form
         */
        applyUrlParams: function() {
            const params = DOM.getUrlParams();

            const service = params.get(BOOKING_CONFIG.urlParamService);
            const date = params.get(BOOKING_CONFIG.urlParamDate);
            const guests = params.get(BOOKING_CONFIG.urlParamGuests);

            if (service) {
                const serviceSelect = this.form.querySelector('select[name="service"]');
                if (serviceSelect) {
                    const options = Array.from(serviceSelect.options);
                    const match = options.find(function(opt) {
                        return opt.value.toLowerCase() === service.toLowerCase();
                    });
                    if (match) serviceSelect.value = match.value;
                }
            }

            if (date) {
                const dateInput = this.form.querySelector('input[name="date"]');
                if (dateInput) dateInput.value = date;
            }

            if (guests) {
                const guestsInput = this.form.querySelector('input[name="guests"]');
                if (guestsInput) guestsInput.value = guests;
            }
        }

        /**
         * Handle booking intent from session
         */
        handleBookingIntent: function() {
            const intent = sessionStorage.getItem(BOOKING_CONFIG.sessionKey);
            if (intent === 'true') {
                sessionStorage.removeItem(BOOKING_CONFIG.sessionKey);

                if (DOM.isContactPage()) {
                    setTimeout(function() {
                        const container = this.elements.container;
                        if (container) {
                            const targetPosition = container.getBoundingClientRect().top + 
                                window.pageYOffset - BOOKING_CONFIG.scrollOffset;
                            window.scrollTo({ 
                                top: targetPosition, 
                                behavior: 'smooth' 
                            });
                        }
                    }.bind(this), BOOKING_CONFIG.successScrollDelay);
                }
            }
        }
    }

    // ============================================================
    // 6. QUICK BOOKING HANDLER
    // ============================================================
    const QuickBookingHandler = {
        /**
         * Initialize quick booking buttons
         */
        init: function() {
            const buttons = DOM.getQuickBookingButtons();

            buttons.forEach(function(button) {
                button.addEventListener('click', function(e) {
                    this.handleClick(e, button);
                }.bind(this));
            }.bind(this));
        },

        /**
         * Handle quick booking button click
         */
        handleClick: function(e, button) {
            const href = button.getAttribute('href');

            if (href && href.includes('contact.html')) {
                // Store booking intent
                sessionStorage.setItem(BOOKING_CONFIG.sessionKey, 'true');

                // If on contact page, scroll to booking form
                if (DOM.isContactPage()) {
                    e.preventDefault();
                    const bookingSection = DOM.getBookingSection();
                    if (bookingSection) {
                        const targetPosition = bookingSection.getBoundingClientRect().top + 
                            window.pageYOffset - BOOKING_CONFIG.scrollOffset;
                        window.scrollTo({ 
                            top: targetPosition, 
                            behavior: 'smooth' 
                        });
                    }
                }
            }
        }
    };

    // ============================================================
    // 7. BOOKING ENGINE INITIALIZATION
    // ============================================================
    const BookingEngine = {
        handlers: [],

        /**
         * Initialize all booking forms
         */
        init: function() {
            // Only run on pages with forms
            const forms = DOM.getForms();
            if (!forms.length) return;

            forms.forEach(function(form) {
                const handler = new BookingFormHandler(form);
                this.handlers.push(handler);
            }.bind(this));

            QuickBookingHandler.init();

            console.log('📅 Booking Engine initialized with ' + this.handlers.length + ' forms');
        },

        /**
         * Get all handlers (for debugging)
         */
        getHandlers: function() {
            return this.handlers;
        },

        /**
         * Reset all forms
         */
        resetAll: function() {
            this.handlers.forEach(function(handler) {
                UIController.resetForm(handler.form);
            });
        }
    };

    // ============================================================
    // 8. BOOT
    // ============================================================

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            BookingEngine.init();
        });
    } else {
        BookingEngine.init();
    }

})();