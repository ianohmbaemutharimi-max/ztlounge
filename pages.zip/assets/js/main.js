/**
 * ============================================================
 * ZT Lounge Meru - Main JavaScript
 * Enterprise Application Controller
 * 
 * Architecture: Clean separation of concerns
 * Organization: Configuration → DOM Cache → Utilities → Modules → Init
 * ============================================================
 */

(function() {
    'use strict';

    // ============================================================
    // 1. CONFIGURATION
    // ============================================================
    const CONFIG = {
        // Header
        headerScrollThreshold: 50,

        // Hero Slider
        sliderInterval: 6000,
        swipeThreshold: 50,

        // Scroll Effects
        revealThreshold: 0.1,
        revealRootMargin: '0px 0px -50px 0px',
        revealDuration: 600,

        // Navigation
        mobileBreakpoint: 768,

        // Smooth Scroll
        scrollOffsetBuffer: 80,

        // Hash Scroll
        hashScrollDelay: 500,

        // Debounce
        resizeDebounce: 250,

        // Reduced Motion
        reducedMotionQuery: '(prefers-reduced-motion: reduce)'
    };

    // ============================================================
    // 2. DOM CACHE
    // ============================================================
    const DOM = {
        // Header
        header: document.getElementById('header'),
        hamburger: document.getElementById('hamburger'),
        navMenu: document.getElementById('navMenu'),

        // Hero Slider
        heroSlider: document.querySelector('.hero-slider'),
        hero: document.getElementById('hero'),
        slides: document.querySelectorAll('.hero-slide'),
        dots: document.querySelectorAll('.dot'),
        prevBtn: document.getElementById('prevSlide'),
        nextBtn: document.getElementById('nextSlide'),

        // Navigation
        navLinks: document.querySelectorAll('.nav-list a'),

        // Scroll Reveal
        revealElements: document.querySelectorAll(
            '.service-card, .experience-card, .event-card, .testimonial-card, .gallery-preview-item'
        ),

        // Hash Links
        anchorLinks: document.querySelectorAll('a[href^="#"]')
    };

    // ============================================================
    // 3. UTILITY FUNCTIONS
    // ============================================================

    /**
     * Debounce - Limits function execution rate
     */
    function debounce(func, wait) {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    /**
     * Get header offset with fallback
     */
    function getHeaderOffset() {
        return DOM.header ? DOM.header.offsetHeight : CONFIG.scrollOffsetBuffer;
    }

    /**
     * Get computed nav height from CSS variable
     */
    function getNavHeight() {
        const navHeight = getComputedStyle(document.documentElement)
            .getPropertyValue('--nav-height');
        return parseInt(navHeight) || getHeaderOffset();
    }

    /**
     * Check if reduced motion is preferred
     */
    function prefersReducedMotion() {
        return window.matchMedia(CONFIG.reducedMotionQuery).matches;
    }

    /**
     * Get filename from path
     */
    function getFilenameFromPath(path) {
        return path ? path.split('/').pop() || 'index.html' : '';
    }

    // ============================================================
    // 4. HEADER MODULE
    // ============================================================
    const Header = {
        /**
         * Initialize header functionality
         */
        init: function() {
            this.initScrollEffect();
            this.initMobileNavigation();
            this.initAnchorScroll();
        },

        /**
         * Header scroll effect - adds class on scroll
         */
        initScrollEffect: function() {
            if (!DOM.header) return;

            const handleScroll = function() {
                const isScrolled = window.scrollY > CONFIG.headerScrollThreshold;
                DOM.header.classList.toggle('scrolled', isScrolled);
            };

            window.addEventListener('scroll', handleScroll, { passive: true });
            handleScroll(); // Initial check
        },

        /**
         * Mobile navigation toggle
         */
        initMobileNavigation: function() {
            if (!DOM.hamburger || !DOM.navMenu) return;

            const toggleMenu = function(e) {
                e.stopPropagation();
                DOM.hamburger.classList.toggle('active');
                DOM.navMenu.classList.toggle('active');
                const isActive = DOM.navMenu.classList.contains('active');
                DOM.hamburger.setAttribute('aria-expanded', String(isActive));
                document.body.style.overflow = isActive ? 'hidden' : '';
            };

            const closeMenu = function() {
                DOM.hamburger.classList.remove('active');
                DOM.navMenu.classList.remove('active');
                DOM.hamburger.setAttribute('aria-expanded', 'false');
                document.body.style.overflow = '';
            };

            // Toggle on hamburger click
            DOM.hamburger.addEventListener('click', toggleMenu);

            // Close on link click (mobile)
            DOM.navMenu.querySelectorAll('a').forEach(function(link) {
                link.addEventListener('click', function() {
                    if (window.innerWidth <= CONFIG.mobileBreakpoint) {
                        closeMenu();
                    }
                });
            });

            // Close on outside click
            document.addEventListener('click', function(e) {
                if (DOM.header && !DOM.header.contains(e.target) && 
                    DOM.navMenu.classList.contains('active')) {
                    closeMenu();
                }
            });

            // Close on Escape
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && DOM.navMenu.classList.contains('active')) {
                    closeMenu();
                    DOM.hamburger.focus();
                }
            });
        },

        /**
         * Smooth scroll for anchor links
         */
        initAnchorScroll: function() {
            DOM.anchorLinks.forEach(function(anchor) {
                anchor.addEventListener('click', function(e) {
                    const href = this.getAttribute('href');
                    if (!href || href === '#') return;

                    const target = document.querySelector(href);
                    if (!target) return;

                    e.preventDefault();
                    const offset = getHeaderOffset();
                    const targetPosition = target.getBoundingClientRect().top + 
                        window.pageYOffset - offset;

                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                });
            });
        }
    };

    // ============================================================
    // 5. NAVIGATION MODULE
    // ============================================================
    const Navigation = {
        /**
         * Initialize navigation functionality
         */
        init: function() {
            this.setActiveLink();
            this.scrollToHash();
        },

        /**
         * Set active navigation link based on current page
         */
        setActiveLink: function() {
            const currentFile = getFilenameFromPath(window.location.pathname);

            DOM.navLinks.forEach(function(link) {
                link.classList.remove('active');
                link.removeAttribute('aria-current');

                const href = link.getAttribute('href');
                if (!href || href.startsWith('#') || href.startsWith('http')) return;

                const linkFile = getFilenameFromPath(href);

                if (linkFile === currentFile) {
                    link.classList.add('active');
                    link.setAttribute('aria-current', 'page');
                }
            });
        },

        /**
         * Auto-scroll to hash on page load
         */
        scrollToHash: function() {
            if (!window.location.hash) return;

            setTimeout(function() {
                const target = document.querySelector(window.location.hash);
                if (!target) return;

                const offset = getNavHeight();
                const targetPosition = target.getBoundingClientRect().top + 
                    window.pageYOffset - offset;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }, CONFIG.hashScrollDelay);
        }
    };

    // ============================================================
    // 6. HERO SLIDER MODULE
    // ============================================================
    const HeroSlider = {
        currentSlide: 0,
        slideInterval: null,

        /**
         * Initialize hero slider
         */
        init: function() {
            if (!DOM.slides.length || !DOM.dots.length) return;

            this.goTo(0);
            this.bindEvents();
            this.startAutoPlay();

            // Pause on hover
            if (DOM.hero) {
                DOM.hero.addEventListener('mouseenter', () => this.stopAutoPlay());
                DOM.hero.addEventListener('mouseleave', () => this.startAutoPlay());
            }
        },

        /**
         * Navigate to specific slide
         */
        goTo: function(index) {
            const slides = DOM.slides;
            const dots = DOM.dots;

            if (index < 0) index = slides.length - 1;
            if (index >= slides.length) index = 0;

            slides.forEach(function(slide, i) {
                const isActive = i === index;
                slide.classList.toggle('active', isActive);
                slide.setAttribute('aria-hidden', String(!isActive));

                // Manage focus for interactive elements
                slide.querySelectorAll('a, button').forEach(function(el) {
                    el.tabIndex = isActive ? 0 : -1;
                });
            });

            dots.forEach(function(dot, i) {
                const isActive = i === index;
                dot.classList.toggle('active', isActive);
                dot.setAttribute('aria-selected', String(isActive));
                dot.tabIndex = isActive ? 0 : -1;
            });

            this.currentSlide = index;
        },

        /**
         * Go to next slide
         */
        next: function() {
            this.goTo(this.currentSlide + 1);
        },

        /**
         * Go to previous slide
         */
        prev: function() {
            this.goTo(this.currentSlide - 1);
        },

        /**
         * Start auto-play
         */
        startAutoPlay: function() {
            if (DOM.slides.length <= 1) return;
            this.stopAutoPlay();
            this.slideInterval = setInterval(
                () => this.next(), 
                CONFIG.sliderInterval
            );
        },

        /**
         * Stop auto-play
         */
        stopAutoPlay: function() {
            if (this.slideInterval) {
                clearInterval(this.slideInterval);
                this.slideInterval = null;
            }
        },

        /**
         * Reset auto-play (stop + start)
         */
        resetAutoPlay: function() {
            this.stopAutoPlay();
            this.startAutoPlay();
        },

        /**
         * Bind event listeners
         */
        bindEvents: function() {
            // Dot clicks
            DOM.dots.forEach((dot, index) => {
                dot.addEventListener('click', () => {
                    this.goTo(index);
                    this.resetAutoPlay();
                });
                dot.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        this.goTo(index);
                        this.resetAutoPlay();
                    }
                });
            });

            // Prev/Next buttons
            if (DOM.prevBtn) {
                DOM.prevBtn.addEventListener('click', () => {
                    this.prev();
                    this.resetAutoPlay();
                });
            }

            if (DOM.nextBtn) {
                DOM.nextBtn.addEventListener('click', () => {
                    this.next();
                    this.resetAutoPlay();
                });
            }

            // Keyboard navigation (scoped to hero slider)
            if (DOM.heroSlider) {
                DOM.heroSlider.addEventListener('keydown', (e) => {
                    if (e.key === 'ArrowLeft') {
                        e.preventDefault();
                        this.prev();
                        this.resetAutoPlay();
                    } else if (e.key === 'ArrowRight') {
                        e.preventDefault();
                        this.next();
                        this.resetAutoPlay();
                    }
                });
            }

            // Touch swipe support
            if (DOM.heroSlider) {
                let touchStartX = 0;

                DOM.heroSlider.addEventListener('touchstart', (e) => {
                    touchStartX = e.changedTouches[0].screenX;
                }, { passive: true });

                DOM.heroSlider.addEventListener('touchend', (e) => {
                    const touchEndX = e.changedTouches[0].screenX;
                    const diff = touchStartX - touchEndX;

                    if (Math.abs(diff) > CONFIG.swipeThreshold) {
                        if (diff > 0) {
                            this.next();
                        } else {
                            this.prev();
                        }
                        this.resetAutoPlay();
                    }
                }, { passive: true });
            }
        }
    };

    // ============================================================
    // 7. SCROLL REVEAL MODULE
    // ============================================================
    const ScrollReveal = {
        observer: null,

        /**
         * Initialize scroll reveal animations
         */
        init: function() {
            if (!DOM.revealElements.length) return;
            if (prefersReducedMotion()) return;
            if (!('IntersectionObserver' in window)) return;

            this.observer = new IntersectionObserver(
                (entries) => this.handleIntersection(entries),
                {
                    threshold: CONFIG.revealThreshold,
                    rootMargin: CONFIG.revealRootMargin
                }
            );

            this.setupElements();
        },

        /**
         * Setup elements with initial state
         */
        setupElements: function() {
            DOM.revealElements.forEach((el) => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(30px)';
                el.style.transition = `opacity ${CONFIG.revealDuration}ms ease, transform ${CONFIG.revealDuration}ms ease`;
                this.observer.observe(el);
            });
        },

        /**
         * Handle intersection events
         */
        handleIntersection: function(entries) {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    const el = entry.target;
                    el.style.opacity = '1';
                    el.style.transform = 'translateY(0)';
                    this.observer.unobserve(el);
                }
            });
        }
    };

    // ============================================================
    // 8. RESIZE HANDLER
    // ============================================================
    const ResizeHandler = {
        /**
         * Initialize resize handler
         */
        init: function() {
            const debouncedResize = debounce(
                () => this.handleResize(),
                CONFIG.resizeDebounce
            );
            window.addEventListener('resize', debouncedResize);
        },

        /**
         * Handle resize events
         */
        handleResize: function() {
            // Any resize-specific logic goes here
            // Currently empty as placeholder for future needs
        }
    };

    // ============================================================
    // 9. CONSOLE BRANDING
    // ============================================================
    const ConsoleBranding = {
        /**
         * Display console branding
         */
        init: function() {
            // Keep existing console branding or add new
            // Minimal impact - preserve what was there
        }
    };

    // ============================================================
    // 10. APPLICATION INITIALIZATION
    // ============================================================
    const App = {
        /**
         * Initialize all application modules
         */
        init: function() {
            // Order matters - dependencies first
            Header.init();
            Navigation.init();
            HeroSlider.init();
            ScrollReveal.init();
            ResizeHandler.init();
            ConsoleBranding.init();

            this.logStartup();
        },

        /**
         * Log startup confirmation
         */
        logStartup: function() {
            if (window.console) {
                console.log('🚀 ZT Lounge App initialized successfully');
            }
        }
    };

    // ============================================================
    // 11. BOOT
    // ============================================================

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => App.init());
    } else {
        // DOM already loaded
        App.init();
    }

})();