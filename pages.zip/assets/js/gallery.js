/**
 * ZT Lounge Meru - Gallery JavaScript
 * Handles gallery filtering, lightbox, and image interactions
 * Refactored for Design System Integration - Version 2.0.0
 */

document.addEventListener('DOMContentLoaded', function() {
    'use strict';

    // ============================================
    // CONFIGURATION
    // ============================================
    const CONFIG = {
        lazyLoadThreshold: 0.01,
        lazyLoadRootMargin: '100px 0px',
        lightboxAnimationDuration: 300,
        galleryAnimationDelay: 50,
        preloadAdjacentCount: 2,
        keyboardNavigation: true,
        smoothScroll: true,
        touchSwipe: true
    };

    // ============================================
    // STATE MANAGEMENT
    // ============================================
    const state = {
        lightbox: {
            isOpen: false,
            currentIndex: 0,
            images: [],
            isAnimating: false
        },
        gallery: {
            currentFilter: 'all',
            items: [],
            isFiltering: false
        }
    };

    // ============================================
    // DOM REFS
    // ============================================
    const DOM = {
        // Lightbox
        lightbox: document.getElementById('lightbox'),
        lightboxImg: document.getElementById('lightbox-img'),
        lightboxCaption: document.getElementById('lightbox-caption'),
        lightboxCounter: document.getElementById('lightbox-counter'),
        closeLightbox: document.getElementById('close-lightbox'),
        prevLightbox: document.getElementById('prev-lightbox'),
        nextLightbox: document.getElementById('next-lightbox'),
        
        // Gallery
        filterButtons: document.querySelectorAll('.gallery-filter button'),
        galleryItems: document.querySelectorAll('.gallery-item'),
        galleryCounter: document.getElementById('gallery-counter'),
        galleryGrids: document.querySelectorAll('.gallery-grid'),
        
        // Images
        allImages: document.querySelectorAll('img'),
        lazyImages: [],
        heroImages: document.querySelectorAll('.image-hero'),
        galleryImages: document.querySelectorAll('.image-gallery'),
        serviceImages: document.querySelectorAll('.image-service'),
        roomImages: document.querySelectorAll('.image-room'),
        teamImages: document.querySelectorAll('.image-team'),
        foodImages: document.querySelectorAll('.image-food'),
        testimonialImages: document.querySelectorAll('.image-testimonial')
    };

    // ============================================
    // UTILITY FUNCTIONS
    // ============================================
    const utils = {
        debounce: function(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },

        throttle: function(func, limit) {
            let inThrottle;
            return function(...args) {
                if (!inThrottle) {
                    func.apply(this, args);
                    inThrottle = true;
                    setTimeout(() => inThrottle = false, limit);
                }
            };
        },

        getImageDimensions: function(img) {
            return new Promise((resolve) => {
                if (img.complete) {
                    resolve({ width: img.naturalWidth, height: img.naturalHeight });
                } else {
                    img.addEventListener('load', () => {
                        resolve({ width: img.naturalWidth, height: img.naturalHeight });
                    });
                    img.addEventListener('error', () => {
                        resolve({ width: 0, height: 0 });
                    });
                }
            });
        },

        isElementInViewport: function(el) {
            const rect = el.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        },

        getImageCaption: function(img) {
            return img.getAttribute('data-caption') || 
                   img.getAttribute('alt') || 
                   img.title || 
                   'ZT Lounge Meru';
        },

        formatCounter: function(current, total) {
            return `${current + 1} / ${total}`;
        },

        preloadImage: function(src) {
            return new Promise((resolve, reject) => {
                const img = new Image();
                img.onload = () => resolve(img);
                img.onerror = reject;
                img.src = src;
            });
        },

        getTouchDirection: function(startX, startY, endX, endY) {
            const dx = endX - startX;
            const dy = endY - startY;
            const absDx = Math.abs(dx);
            const absDy = Math.abs(dy);
            
            if (Math.max(absDx, absDy) < 50) return null;
            
            if (absDx > absDy) {
                return dx > 0 ? 'right' : 'left';
            } else {
                return dy > 0 ? 'down' : 'up';
            }
        }
    };

    // ============================================
    // DESIGN SYSTEM - IMAGE VALIDATION
    // ============================================
    class ImageDesignSystem {
        constructor() {
            this.rules = {
                'image-hero': { aspectRatio: '16:9', minWidth: 1200, maxWidth: 1920 },
                'image-gallery': { aspectRatio: '1:1', minWidth: 400, maxWidth: 800 },
                'image-service': { aspectRatio: '16:10', minWidth: 600, maxWidth: 800 },
                'image-room': { aspectRatio: '16:9', minWidth: 800, maxWidth: 1200 },
                'image-team': { aspectRatio: '3:4', minWidth: 400, maxWidth: 600 },
                'image-food': { aspectRatio: '1:1', minWidth: 400, maxWidth: 800 },
                'image-testimonial': { aspectRatio: '1:1', minWidth: 60, maxWidth: 80 }
            };
        }

        validateImage(img) {
            const className = img.className;
            const rule = this.rules[className];
            
            if (!rule) return { valid: true, message: 'No specific rule for this image class' };

            return new Promise((resolve) => {
                utils.getImageDimensions(img).then(({ width, height }) => {
                    if (width === 0 || height === 0) {
                        resolve({ 
                            valid: false, 
                            message: 'Image dimensions could not be determined',
                            severity: 'warning'
                        });
                        return;
                    }

                    const aspectRatio = width / height;
                    const expectedRatio = this.parseAspectRatio(rule.aspectRatio);
                    const ratioDiff = Math.abs(aspectRatio - expectedRatio) / expectedRatio;

                    let valid = true;
                    let messages = [];

                    if (width < rule.minWidth) {
                        valid = false;
                        messages.push(`Image width (${width}px) is below minimum (${rule.minWidth}px)`);
                    }

                    if (width > rule.maxWidth) {
                        valid = false;
                        messages.push(`Image width (${width}px) exceeds maximum (${rule.maxWidth}px)`);
                    }

                    if (ratioDiff > 0.1) {
                        valid = false;
                        messages.push(`Aspect ratio (${aspectRatio.toFixed(2)}) differs from expected (${rule.aspectRatio})`);
                    }

                    resolve({
                        valid,
                        message: messages.join('; ') || 'Image meets design system requirements',
                        severity: valid ? 'success' : 'error',
                        dimensions: { width, height },
                        expected: rule
                    });
                });
            });
        }

        parseAspectRatio(ratio) {
            const parts = ratio.split(':');
            return parseFloat(parts[0]) / parseFloat(parts[1]);
        }

        async auditImages() {
            const results = [];
            const images = document.querySelectorAll('[class*="image-"]');
            
            for (const img of images) {
                const result = await this.validateImage(img);
                results.push({
                    element: img,
                    src: img.src,
                    className: img.className,
                    ...result
                });
            }

            return results;
        }
    }

    // ============================================
    // LAZY LOADING SYSTEM
    // ============================================
    class LazyLoader {
        constructor(options = {}) {
            this.options = {
                threshold: CONFIG.lazyLoadThreshold,
                rootMargin: CONFIG.lazyLoadRootMargin,
                ...options
            };
            
            this.observer = null;
            this.images = [];
            this.loadedCount = 0;
            
            this.init();
        }

        init() {
            if ('IntersectionObserver' in window) {
                this.observer = new IntersectionObserver(
                    this.handleIntersection.bind(this),
                    {
                        threshold: this.options.threshold,
                        rootMargin: this.options.rootMargin
                    }
                );
                
                this.setupLazyImages();
            } else {
                this.loadAllImages();
            }
        }

        setupLazyImages() {
            // Find all images that need lazy loading
            const lazyImages = document.querySelectorAll('img[data-src]');
            
            lazyImages.forEach(img => {
                // Skip images that already have a valid src
                if (img.src && !img.src.startsWith('data:')) {
                    return;
                }
                
                this.images.push(img);
                this.observer.observe(img);
            });

            // Also handle images with loading="lazy" attribute
            const loadingLazy = document.querySelectorAll('img[loading="lazy"]');
            loadingLazy.forEach(img => {
                if (!this.images.includes(img) && !img.dataset.src) {
                    // If image has a src but loading=lazy, observe it for performance metrics
                    this.observer.observe(img);
                }
            });
        }

        handleIntersection(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    this.loadImage(img);
                    this.observer.unobserve(img);
                }
            });
        }

        loadImage(img) {
            if (img.dataset.src) {
                const src = img.dataset.src;
                
                // Show loading state
                img.style.opacity = '0.3';
                
                const tempImg = new Image();
                tempImg.onload = () => {
                    img.src = src;
                    img.removeAttribute('data-src');
                    img.style.opacity = '1';
                    img.classList.add('image-loaded');
                    this.loadedCount++;
                    
                    // Dispatch event for analytics
                    this.dispatchEvent('imageLoaded', { img, src });
                };
                tempImg.onerror = () => {
                    // Fallback to placeholder if available
                    if (img.dataset.fallback) {
                        img.src = img.dataset.fallback;
                    }
                    img.removeAttribute('data-src');
                    img.style.opacity = '1';
                    this.dispatchEvent('imageError', { img, src });
                };
                tempImg.src = src;
            } else if (img.src) {
                // Image already has src, just track it
                img.classList.add('image-loaded');
                this.loadedCount++;
            }
        }

        loadAllImages() {
            this.images.forEach(img => this.loadImage(img));
        }

        dispatchEvent(eventName, detail) {
            const event = new CustomEvent(`lazyLoader:${eventName}`, { detail });
            document.dispatchEvent(event);
        }

        getStats() {
            return {
                total: this.images.length,
                loaded: this.loadedCount,
                pending: this.images.length - this.loadedCount
            };
        }
    }

    // ============================================
    // GALLERY FILTER SYSTEM
    // ============================================
    class GalleryFilter {
        constructor() {
            this.buttons = DOM.filterButtons;
            this.items = DOM.galleryItems;
            this.counter = DOM.galleryCounter;
            this.currentFilter = 'all';
            this.isAnimating = false;
            
            this.init();
        }

        init() {
            if (this.buttons.length === 0 || this.items.length === 0) return;
            
            this.buttons.forEach(button => {
                button.addEventListener('click', this.handleFilterClick.bind(this));
                button.addEventListener('keydown', this.handleKeydown.bind(this));
            });
            
            // Initialize counter
            this.updateCounter();
        }

        handleFilterClick(event) {
            const button = event.currentTarget;
            const filter = button.getAttribute('data-filter');
            
            if (this.isAnimating || filter === this.currentFilter) return;
            
            this.applyFilter(filter, button);
        }

        handleKeydown(event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                this.handleFilterClick(event);
            }
        }

        applyFilter(filter, activeButton) {
            this.isAnimating = true;
            this.currentFilter = filter;
            
            // Update active button
            this.buttons.forEach(btn => btn.classList.remove('active'));
            if (activeButton) {
                activeButton.classList.add('active');
            } else {
                // Find the button with matching filter
                const matchingButton = Array.from(this.buttons).find(
                    btn => btn.getAttribute('data-filter') === filter
                );
                if (matchingButton) {
                    matchingButton.classList.add('active');
                }
            }
            
            // Apply filter to items
            this.items.forEach((item, index) => {
                const category = item.getAttribute('data-category');
                const shouldShow = filter === 'all' || category === filter;
                
                if (shouldShow) {
                    this.showItem(item, index);
                } else {
                    this.hideItem(item, index);
                }
            });
            
            // Update counter after animation
            setTimeout(() => {
                this.updateCounter();
                this.isAnimating = false;
                this.dispatchEvent('filterApplied', { filter });
            }, CONFIG.galleryAnimationDelay * 8 + 400);
        }

        showItem(item, index) {
            item.style.display = 'block';
            item.style.opacity = '0';
            item.style.transform = 'scale(0.95) translateY(20px)';
            
            // Trigger reflow
            void item.offsetWidth;
            
            setTimeout(() => {
                item.style.transition = `opacity 0.5s ease ${index * 0.05}s, transform 0.5s ease ${index * 0.05}s`;
                item.style.opacity = '1';
                item.style.transform = 'scale(1) translateY(0)';
            }, CONFIG.galleryAnimationDelay);
        }

        hideItem(item, index) {
            item.style.transition = `opacity 0.4s ease ${index * 0.03}s, transform 0.4s ease ${index * 0.03}s`;
            item.style.opacity = '0';
            item.style.transform = 'scale(0.95) translateY(20px)';
            
            setTimeout(() => {
                item.style.display = 'none';
            }, CONFIG.galleryAnimationDelay * 6 + 400);
        }

        updateCounter() {
            if (!this.counter) return;
            
            const visibleItems = Array.from(this.items).filter(
                item => item.style.display !== 'none'
            ).length;
            
            const total = this.items.length;
            const filterName = this.currentFilter !== 'all' ? 
                ` (${this.currentFilter})` : '';
            
            this.counter.textContent = `${visibleItems} of ${total} photos${filterName}`;
            this.counter.setAttribute('aria-label', 
                `Showing ${visibleItems} of ${total} gallery items${filterName}`
            );
        }

        dispatchEvent(eventName, detail) {
            const event = new CustomEvent(`gallery:${eventName}`, { detail });
            document.dispatchEvent(event);
        }
    }

    // ============================================
    // LIGHTBOX SYSTEM
    // ============================================
    class Lightbox {
        constructor() {
            this.element = DOM.lightbox;
            this.img = DOM.lightboxImg;
            this.caption = DOM.lightboxCaption;
            this.counter = DOM.lightboxCounter;
            this.closeBtn = DOM.closeLightbox;
            this.prevBtn = DOM.prevLightbox;
            this.nextBtn = DOM.nextLightbox;
            
            this.images = [];
            this.currentIndex = 0;
            this.isOpen = false;
            this.isAnimating = false;
            this.touchStartX = 0;
            this.touchStartY = 0;
            
            this.init();
        }

        init() {
            // Setup click listeners for all gallery images
            this.setupImageTriggers();
            
            // Setup controls
            this.setupControls();
            
            // Setup keyboard navigation
            if (CONFIG.keyboardNavigation) {
                this.setupKeyboardNavigation();
            }
            
            // Setup touch support
            if (CONFIG.touchSwipe) {
                this.setupTouchSupport();
            }
        }

        setupImageTriggers() {
            // All images that should open lightbox
            const triggers = document.querySelectorAll(
                '.gallery-item img, .gallery-preview-item img, ' +
                '.service-detail-image img, .about-image img, ' +
                '.room-image, .food-image, [data-lightbox]'
            );
            
            triggers.forEach(img => {
                img.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.openFromImage(img);
                });
                
                // ARIA support
                img.setAttribute('role', 'button');
                img.setAttribute('tabindex', '0');
                img.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        this.openFromImage(img);
                    }
                });
            });
        }

        openFromImage(clickedImg) {
            // Find all images in the same container
            const parent = clickedImg.closest('.gallery-grid') || 
                          clickedImg.closest('.gallery-preview-grid') || 
                          clickedImg.closest('.service-detail-grid') || 
                          clickedImg.closest('.about-grid') ||
                          clickedImg.closest('.image-grid');
            
            if (parent) {
                const allImgs = parent.querySelectorAll('img');
                this.images = Array.from(allImgs).map(i => i.getAttribute('src'));
                const index = this.images.indexOf(clickedImg.getAttribute('src'));
                if (index !== -1) {
                    this.open(index);
                }
            } else {
                // Single image or custom lightbox group
                const group = clickedImg.getAttribute('data-lightbox-group');
                if (group) {
                    // Find all images with same group
                    const groupImages = document.querySelectorAll(
                        `[data-lightbox-group="${group}"]`
                    );
                    this.images = Array.from(groupImages).map(i => i.getAttribute('src'));
                    const index = this.images.indexOf(clickedImg.getAttribute('src'));
                    if (index !== -1) {
                        this.open(index);
                    }
                } else {
                    this.images = [clickedImg.getAttribute('src')];
                    this.open(0);
                }
            }
        }

        open(index) {
            if (this.isOpen || this.isAnimating) return;
            if (!this.images || this.images.length === 0) return;
            
            this.currentIndex = Math.max(0, Math.min(index, this.images.length - 1));
            this.isOpen = true;
            
            // Show lightbox
            this.element.classList.add('active');
            document.body.style.overflow = 'hidden';
            
            // Load image
            this.loadImage(this.currentIndex);
            
            // Update UI
            this.updateControls();
            
            // Preload adjacent images
            this.preloadAdjacentImages();
            
            // Dispatch event
            this.dispatchEvent('opened', { index: this.currentIndex, total: this.images.length });
        }

        loadImage(index) {
            if (this.isAnimating) return;
            
            const src = this.images[index];
            if (!src) return;
            
            this.isAnimating = true;
            
            // Show loading state
            this.img.style.opacity = '0.3';
            
            // Preload image
            utils.preloadImage(src)
                .then((loadedImg) => {
                    this.img.src = src;
                    this.img.alt = this.getImageCaption(index);
                    
                    // Update caption
                    this.updateCaption(index);
                    
                    // Update counter
                    this.updateCounter(index);
                    
                    // Show image
                    this.img.style.opacity = '1';
                    this.isAnimating = false;
                    
                    // Preload more
                    this.preloadAdjacentImages();
                })
                .catch(() => {
                    // Error handling - show placeholder
                    this.img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="400"%3E%3Crect fill="%23f0edea" width="400" height="400"/%3E%3Ctext x="50%25" y="50%25" font-family="sans-serif" font-size="20" fill="%23999" text-anchor="middle" dy=".3em"%3EImage unavailable%3C/text%3E%3C/svg%3E';
                    this.img.alt = 'Image unavailable';
                    this.isAnimating = false;
                });
        }

        getImageCaption(index) {
            const src = this.images[index];
            const imgElement = document.querySelector(`img[src="${src}"]`);
            if (imgElement) {
                return utils.getImageCaption(imgElement);
            }
            return `ZT Lounge Meru - Gallery image ${index + 1}`;
        }

        updateCaption(index) {
            if (this.caption) {
                const caption = this.getImageCaption(index);
                this.caption.textContent = caption;
                this.caption.setAttribute('aria-label', caption);
            }
        }

        updateCounter(index) {
            if (this.counter && this.images.length > 1) {
                this.counter.textContent = utils.formatCounter(index, this.images.length);
                this.counter.setAttribute('aria-label', 
                    `Image ${index + 1} of ${this.images.length}`
                );
            }
        }

        updateControls() {
            // Show/hide navigation based on number of images
            if (this.images.length <= 1) {
                if (this.prevBtn) this.prevBtn.style.display = 'none';
                if (this.nextBtn) this.nextBtn.style.display = 'none';
            } else {
                if (this.prevBtn) this.prevBtn.style.display = 'block';
                if (this.nextBtn) this.nextBtn.style.display = 'block';
            }
        }

        preloadAdjacentImages() {
            const count = CONFIG.preloadAdjacentCount;
            for (let i = 1; i <= count; i++) {
                // Preload next
                const nextIndex = (this.currentIndex + i) % this.images.length;
                if (nextIndex !== this.currentIndex) {
                    utils.preloadImage(this.images[nextIndex]).catch(() => {});
                }
                
                // Preload previous
                const prevIndex = (this.currentIndex - i + this.images.length) % this.images.length;
                if (prevIndex !== this.currentIndex) {
                    utils.preloadImage(this.images[prevIndex]).catch(() => {});
                }
            }
        }

        close() {
            if (!this.isOpen || this.isAnimating) return;
            
            this.isOpen = false;
            this.element.classList.remove('active');
            document.body.style.overflow = '';
            
            this.dispatchEvent('closed', { index: this.currentIndex });
        }

        navigate(direction) {
            if (this.images.length === 0 || this.isAnimating) return;
            
            const newIndex = (this.currentIndex + direction + this.images.length) % this.images.length;
            if (newIndex === this.currentIndex) return;
            
            this.currentIndex = newIndex;
            this.loadImage(this.currentIndex);
            this.updateCounter(this.currentIndex);
            this.updateCaption(this.currentIndex);
            this.preloadAdjacentImages();
            
            this.dispatchEvent('navigated', { 
                direction, 
                index: this.currentIndex 
            });
        }

        setupControls() {
            // Close button
            if (this.closeBtn) {
                this.closeBtn.addEventListener('click', () => this.close());
            }
            
            // Navigation buttons
            if (this.prevBtn) {
                this.prevBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.navigate(-1);
                });
            }
            
            if (this.nextBtn) {
                this.nextBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.navigate(1);
                });
            }
            
            // Click on overlay to close
            if (this.element) {
                this.element.addEventListener('click', (e) => {
                    if (e.target === this.element) {
                        this.close();
                    }
                });
            }
        }

        setupKeyboardNavigation() {
            document.addEventListener('keydown', (e) => {
                if (!this.isOpen) return;
                
                switch (e.key) {
                    case 'Escape':
                        e.preventDefault();
                        this.close();
                        break;
                    case 'ArrowLeft':
                        e.preventDefault();
                        this.navigate(-1);
                        break;
                    case 'ArrowRight':
                        e.preventDefault();
                        this.navigate(1);
                        break;
                }
            });
        }

        setupTouchSupport() {
            if (this.element) {
                this.element.addEventListener('touchstart', (e) => {
                    const touch = e.touches[0];
                    this.touchStartX = touch.clientX;
                    this.touchStartY = touch.clientY;
                }, { passive: true });
                
                this.element.addEventListener('touchmove', (e) => {
                    if (!this.touchStartX || !this.touchStartY) return;
                    
                    const touch = e.touches[0];
                    const direction = utils.getTouchDirection(
                        this.touchStartX, 
                        this.touchStartY,
                        touch.clientX, 
                        touch.clientY
                    );
                    
                    if (direction === 'left') {
                        this.navigate(1);
                        this.touchStartX = touch.clientX;
                        this.touchStartY = touch.clientY;
                    } else if (direction === 'right') {
                        this.navigate(-1);
                        this.touchStartX = touch.clientX;
                        this.touchStartY = touch.clientY;
                    }
                }, { passive: true });
            }
        }

        dispatchEvent(eventName, detail) {
            const event = new CustomEvent(`lightbox:${eventName}`, { detail });
            document.dispatchEvent(event);
        }
    }

    // ============================================
    // GALLERY ANIMATION SYSTEM
    // ============================================
    class GalleryAnimation {
        constructor() {
            this.grids = DOM.galleryGrids;
            this.init();
        }

        init() {
            if (this.grids.length === 0) return;
            
            this.grids.forEach(grid => {
                const items = grid.querySelectorAll('.gallery-item');
                
                // Set initial state
                items.forEach((item, index) => {
                    item.style.opacity = '0';
                    item.style.transform = 'translateY(30px) scale(0.98)';
                    item.style.transition = `opacity 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94) ${index * 0.08}s, transform 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94) ${index * 0.08}s`;
                });
                
                // Intersection Observer for animation
                const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const visibleItems = entry.target.querySelectorAll('.gallery-item');
                            visibleItems.forEach((item, index) => {
                                setTimeout(() => {
                                    item.style.opacity = '1';
                                    item.style.transform = 'translateY(0) scale(1)';
                                }, index * 80);
                            });
                            observer.unobserve(entry.target);
                        }
                    });
                }, {
                    threshold: 0.1,
                    rootMargin: '0px 0px -50px 0px'
                });
                
                observer.observe(grid);
            });
        }
    }

    // ============================================
    // PERFORMANCE MONITOR
    // ============================================
    class PerformanceMonitor {
        constructor() {
            this.metrics = {
                imagesLoaded: 0,
                totalImages: 0,
                layoutShifts: 0,
                largestContentfulPaint: 0
            };
            
            this.init();
        }

        init() {
            // Monitor LCP
            if ('PerformanceObserver' in window) {
                try {
                    const lcpObserver = new PerformanceObserver((entryList) => {
                        const entries = entryList.getEntries();
                        const lastEntry = entries[entries.length - 1];
                        this.metrics.largestContentfulPaint = lastEntry.startTime;
                    });
                    lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });
                    
                    // Monitor layout shifts
                    const clsObserver = new PerformanceObserver((entryList) => {
                        for (const entry of entryList.getEntries()) {
                            if (!entry.hadRecentInput) {
                                this.metrics.layoutShifts += entry.value;
                            }
                        }
                    });
                    clsObserver.observe({ entryTypes: ['layout-shift'] });
                } catch (e) {
                    // PerformanceObserver not fully supported
                }
            }
            
            // Count images
            this.metrics.totalImages = document.querySelectorAll('img').length;
        }

        trackImageLoad() {
            this.metrics.imagesLoaded++;
        }

        getReport() {
            return {
                ...this.metrics,
                loadProgress: this.metrics.totalImages > 0 ? 
                    (this.metrics.imagesLoaded / this.metrics.totalImages * 100).toFixed(1) : 0
            };
        }
    }

    // ============================================
    // RESPONSIVE IMAGE HANDLER
    // ============================================
    class ResponsiveImageHandler {
        constructor() {
            this.breakpoints = {
                mobile: 480,
                tablet: 768,
                laptop: 1024,
                desktop: 1200
            };
            
            this.init();
        }

        init() {
            this.handleResize = utils.debounce(this.handleResize.bind(this), 250);
            window.addEventListener('resize', this.handleResize);
            this.handleResize();
        }

        handleResize() {
            const width = window.innerWidth;
            let breakpoint = 'desktop';
            
            if (width <= this.breakpoints.mobile) breakpoint = 'mobile';
            else if (width <= this.breakpoints.tablet) breakpoint = 'tablet';
            else if (width <= this.breakpoints.laptop) breakpoint = 'laptop';
            
            document.documentElement.setAttribute('data-breakpoint', breakpoint);
            
            // Update images with srcset if needed
            this.updateResponsiveImages(breakpoint);
        }

        updateResponsiveImages(breakpoint) {
            // Images with data-srcset attributes
            document.querySelectorAll('img[data-srcset]').forEach(img => {
                const srcset = img.getAttribute(`data-srcset-${breakpoint}`);
                if (srcset) {
                    img.srcset = srcset;
                }
            });
        }
    }

    // ============================================
    // ACCESSIBILITY ENHANCEMENTS
    // ============================================
    class AccessibilityEnhancer {
        constructor() {
            this.init();
        }

        init() {
            // Ensure all images have alt text
            this.validateAltText();
            
            // Add ARIA labels to gallery controls
            this.enhanceControls();
            
            // Add focus management
            this.setupFocusManagement();
        }

        validateAltText() {
            document.querySelectorAll('img').forEach(img => {
                if (!img.hasAttribute('alt')) {
                    img.setAttribute('alt', '');
                    console.warn('Missing alt attribute:', img);
                }
            });
        }

        enhanceControls() {
            // Gallery filter buttons
            document.querySelectorAll('.gallery-filter button').forEach(btn => {
                const filter = btn.getAttribute('data-filter');
                btn.setAttribute('role', 'tab');
                btn.setAttribute('aria-selected', btn.classList.contains('active') ? 'true' : 'false');
                btn.setAttribute('aria-controls', `gallery-${filter}`);
            });
            
            // Lightbox controls
            const lightboxControls = [
                { id: 'close-lightbox', label: 'Close lightbox' },
                { id: 'prev-lightbox', label: 'Previous image' },
                { id: 'next-lightbox', label: 'Next image' }
            ];
            
            lightboxControls.forEach(({ id, label }) => {
                const el = document.getElementById(id);
                if (el) {
                    el.setAttribute('aria-label', label);
                    el.setAttribute('role', 'button');
                }
            });
        }

        setupFocusManagement() {
            // Trap focus in lightbox when open
            document.addEventListener('lightbox:opened', () => {
                const focusableElements = document.querySelectorAll(
                    '#lightbox button, #lightbox [role="button"]'
                );
                if (focusableElements.length > 0) {
                    focusableElements[0].focus();
                }
            });
        }
    }

    // ============================================
    // INITIALIZATION
    // ============================================
    class App {
        constructor() {
            this.components = {};
            this.performance = new PerformanceMonitor();
            
            this.init();
        }

        init() {
            // Initialize all components
            this.components.lazyLoader = new LazyLoader();
            this.components.galleryFilter = new GalleryFilter();
            this.components.lightbox = new Lightbox();
            this.components.galleryAnimation = new GalleryAnimation();
            this.components.responsiveImages = new ResponsiveImageHandler();
            this.components.accessibility = new AccessibilityEnhancer();
            this.components.designSystem = new ImageDesignSystem();
            
            // Setup global event listeners
            this.setupGlobalListeners();
            
            // Run initial audit
            this.runAudit();
            
            // Dispatch ready event
            document.dispatchEvent(new CustomEvent('gallery:ready'));
            
            console.log('ZT Lounge Meru Gallery System initialized');
            console.log('Performance metrics:', this.performance.getReport());
        }

        setupGlobalListeners() {
            // Handle image load events
            document.addEventListener('lazyLoader:imageLoaded', (e) => {
                this.performance.trackImageLoad();
                this.handleImageLoad(e.detail);
            });
            
            // Handle window resize
            window.addEventListener('resize', utils.debounce(() => {
                this.handleWindowResize();
            }, 200));
        }

        runAudit() {
            // Run design system audit after images are loaded
            window.addEventListener('load', () => {
                setTimeout(() => {
                    this.components.designSystem.auditImages()
                        .then(results => {
                            const errors = results.filter(r => !r.valid);
                            if (errors.length > 0) {
                                console.warn(`Found ${errors.length} images not matching design system:`, errors);
                            }
                            document.dispatchEvent(new CustomEvent('gallery:auditComplete', { 
                                detail: { results, errors } 
                            }));
                        });
                }, 1000);
            });
        }

        handleImageLoad({ img, src }) {
            // Add blur-up effect
            img.classList.add('image-blur-load');
            setTimeout(() => {
                img.classList.remove('image-blur-load');
            }, 1200);
            
            // Track in performance
            this.performance.trackImageLoad();
        }

        handleWindowResize() {
            // Update any responsive elements
            document.querySelectorAll('.gallery-grid').forEach(grid => {
                // Adjust grid if needed
            });
        }

        getComponents() {
            return this.components;
        }

        getPerformanceReport() {
            return this.performance.getReport();
        }
    }

    // ============================================
    // BOOTSTRAP
    // ============================================
    const app = new App();

    // Expose app instance globally for debugging
    if (window) {
        window.ZTGallery = app;
    }

    // Handle DOM content loaded
    console.log('Gallery system initialized successfully');
});